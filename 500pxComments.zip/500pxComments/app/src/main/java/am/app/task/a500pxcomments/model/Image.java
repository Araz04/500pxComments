package am.app.task.a500pxcomments.model;

import java.util.ArrayList;
import java.util.List;

import am.app.task.a500pxcomments.client.Results;

/**
 * Created by 1 on 01.04.2017.
 */

public class Image {

    private int mId;
    private String mImageUrl;
    private List<Comment> mComments = new ArrayList<>();

    private String mImageName;

    public List<Comment> getComments() {
        return mComments;
    }

    public void setComment(List<Comment> comments) {
        mComments = comments;
    }

    public int getId() {
        return mId;
    }

    public void setId(int id) {
        mId = id;
    }

    public String getImageName() {
        return mImageName;
    }

    public void setImageName(String imageName) {
        mImageName = imageName;
    }

    public String getImageUrl() {
        return mImageUrl;
    }

    public void setImageUrl(String imageUrl) {
        mImageUrl = imageUrl;
    }

    public static Image createFromResponse (Results.Photo response) {
        Image image = new Image();
        image.setId(response.id);
        image.setImageName(response.name);
        image.setImageUrl(response.image_url);
        return image;
    }
}

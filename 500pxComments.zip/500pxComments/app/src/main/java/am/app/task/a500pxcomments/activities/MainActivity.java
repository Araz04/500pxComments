package am.app.task.a500pxcomments.activities;

import android.content.Intent;
import android.support.v4.widget.SwipeRefreshLayout;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;

import java.util.ArrayList;
import java.util.List;

import am.app.task.a500pxcomments.R;
import am.app.task.a500pxcomments.adapters.ImagesAdapter;
import am.app.task.a500pxcomments.client.ApiClient;
import am.app.task.a500pxcomments.client.ApiManager;
import am.app.task.a500pxcomments.client.Results;
import am.app.task.a500pxcomments.managers.ImageManager;
import am.app.task.a500pxcomments.model.Image;
import am.app.task.a500pxcomments.utils.PaginationRecyclerView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends BaseActivity {

    private ImageManager mImageManager;
    private ImagesAdapter mImagesAdapter;
    private PaginationRecyclerView mRecyclerView;
    private SwipeRefreshLayout mSwipeRefreshLayout;
    private int mPage = 1;
    private static final int LIMIT = 20;

    private PaginationRecyclerView.OnPaginateListener mOnPaginateListener = new PaginationRecyclerView.OnPaginateListener() {
        @Override
        public void onLoadMore() {
            loadData();
        }
    };

    private ImagesAdapter.OnItemClickListener mOnItemClickListener = new ImagesAdapter.OnItemClickListener() {
        @Override
        public void onItemClicked(Image image) {
            Intent intent = new Intent(MainActivity.this, ImageDetailsActivity.class);
            intent.putExtra(ImageDetailsActivity.PHOTO_ID, image.getId());
            startActivity(intent);
        }
    };

    private SwipeRefreshLayout.OnRefreshListener mOnRefreshListener = new SwipeRefreshLayout.OnRefreshListener() {
        @Override
        public void onRefresh() {
            mSwipeRefreshLayout.setRefreshing(false);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mImageManager = ImageManager.getInstance();
        init();
        if (mImageManager.getImages().size() == 0) {
            loadData();
        } else {
            mImagesAdapter.setPhotos(mImageManager.getImages());
        }
    }

    public void init() {
        mImagesAdapter = new ImagesAdapter(this);
        mImagesAdapter.setOnItemClickListener(mOnItemClickListener);
        mSwipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.swipe_refresh_layout_activity_main);
        mSwipeRefreshLayout.setOnRefreshListener(mOnRefreshListener);

        mRecyclerView = (PaginationRecyclerView) findViewById(R.id.recycler_view_images);
        mRecyclerView.setOnPaginateListener(mOnPaginateListener);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(layoutManager);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setAdapter(mImagesAdapter);
    }

    public void loadData() {
        showLoading();
        Call<Results.PhotoWrapper> call = ApiManager.getApiClient().getPhotos(ApiClient.CONSUMER_KEY, ApiClient.POPULAR_PHOTOS, mPage, ApiClient.IMAGE_SIZE);
        mRecyclerView.setLoading(true);
        call.enqueue(new Callback<Results.PhotoWrapper>() {
            @Override
            public void onResponse(Call<Results.PhotoWrapper> call, Response<Results.PhotoWrapper> response) {
                dissmissLoading();
                List<Image> imageList = new ArrayList<>();
                for (Results.Photo photo : response.body().photos) {
                    Image image = Image.createFromResponse(photo);
                    imageList.add(image);
                }

                mImageManager.addImages(imageList);
                mImagesAdapter.addImages(imageList);
                mPage++;
                mRecyclerView.setLoading(false);
                mRecyclerView.setLastPage(imageList.size() < LIMIT);
            }

            @Override
            public void onFailure(Call<Results.PhotoWrapper> call, Throwable t) {

            }
        });
    }
}

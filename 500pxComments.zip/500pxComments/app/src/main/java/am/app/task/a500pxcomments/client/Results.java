package am.app.task.a500pxcomments.client;

import java.util.List;

/**
 * Created by 1 on 01.04.2017.
 */

public final class Results {

    public static class Photo{
        public int id;
        public String name;
        public String image_url;
    }

    public static class PhotoWrapper{
        public List<Photo> photos;
    }
}

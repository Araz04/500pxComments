package am.app.task.a500pxcomments.adapters;

import android.content.Context;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;

import am.app.task.a500pxcomments.R;
import am.app.task.a500pxcomments.adapters.viewholders.ImagesViewHolder;
import am.app.task.a500pxcomments.model.Image;

/**
 * Created by 1 on 01.04.2017.
 */

public class ImagesAdapter extends RecyclerView.Adapter<ImagesViewHolder> {

    private Context mContext;
    private LayoutInflater mInflater;
    private SparseArray<Image> mData = new SparseArray<>();

    OnItemClickListener mOnItemClickListener;

    public ImagesAdapter(Context context){
        mContext = context;
        mInflater = LayoutInflater.from(context);
    }

    @Override
    public ImagesViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = mInflater.inflate(R.layout.item_images_list, parent, false);
        return new ImagesViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ImagesViewHolder holder, int position) {
        Image image = mData.valueAt(position);
        Glide.with(mContext).load(image.getImageUrl()).centerCrop().into(holder.mImage);
        holder.mImageName.setText(image.getImageName());

        holder.setOnClickListener(new ImagesViewHolder.OnClickListener() {
            @Override
            public void onClick(int position) {
                if (mOnItemClickListener != null) {
                    mOnItemClickListener.onItemClicked(mData.valueAt(position));
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    public void addImages(List<Image> data) {
        for (Image image : data) {
            mData.put(image.getId(), image);
        }

        notifyDataSetChanged();
    }


    public void setPhotos(SparseArray<Image> data) {
        mData = data;
        notifyDataSetChanged();
    }

    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        mOnItemClickListener = onItemClickListener;
    }

    public interface OnItemClickListener{
        void onItemClicked(Image image);
    }
}

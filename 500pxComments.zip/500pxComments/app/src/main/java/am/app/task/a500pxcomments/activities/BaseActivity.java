package am.app.task.a500pxcomments.activities;

import android.app.Dialog;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.Window;

import am.app.task.a500pxcomments.R;

public class BaseActivity extends AppCompatActivity {
    private Dialog mProgressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initLoading();
    }

    private void initLoading() {
        mProgressBar = new Dialog(this, android.R.style.Theme_Translucent);
        mProgressBar.setCancelable(false);
        View view = getLayoutInflater().inflate(R.layout.dialog_progress, null);
        mProgressBar.requestWindowFeature(Window.FEATURE_NO_TITLE);
        mProgressBar.setTitle(null);
        mProgressBar.setCancelable(true);
        mProgressBar.setContentView(view);
    }

    public void showLoading() {
        if (!mProgressBar.isShowing() && !isFinishing()) {
            mProgressBar.show();
        }
    }

    public void dissmissLoading() {
        if (mProgressBar.isShowing() && !isFinishing()) {
            mProgressBar.dismiss();
        }
    }
}

package am.app.task.a500pxcomments.managers;

import android.util.SparseArray;

import java.util.List;

import am.app.task.a500pxcomments.model.Image;

/**
 * Created by 1 on 01.04.2017.
 */

public class ImageManager {

    private static ImageManager mInstance;

    private SparseArray<Image> mImages;

    public static ImageManager getInstance(){
        if (mInstance == null){
            mInstance = new ImageManager();
        }
        return mInstance;
    }


    private ImageManager(){
        mImages = new SparseArray<>();
    }

    public Image getImageById(int id){
        return mImages.get(id);
    }

    public SparseArray<Image> getImages() {
        return mImages;
    }

    public void setImages(SparseArray<Image> images) {
        mImages = images;
    }

    public void addImages(List<Image> images){
        for (Image image: images){
            mImages.put(image.getId(), image);
        }
    }
}

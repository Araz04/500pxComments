package am.app.task.a500pxcomments.client;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Created by 1 on 01.04.2017.
 */

public class ApiManager {

    private static ApiClient sApiClient;

    public static ApiClient getApiClient() {
        if (sApiClient == null) {
            sApiClient = createApiClient();
        }

        return sApiClient;
    }

    private static ApiClient createApiClient() {
        OkHttpClient httpClient = new OkHttpClient.Builder().build();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(ApiClient.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(httpClient)
                .build();

        return retrofit.create(ApiClient.class);
    }
}

package am.app.task.a500pxcomments.adapters.viewholders;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import am.app.task.a500pxcomments.R;

/**
 * Created by 1 on 01.04.2017.
 */

public class ImagesViewHolder extends RecyclerView.ViewHolder{

    public ImageView mImage;
    public TextView mImageName;
    OnClickListener mOnClickListener;

    public ImagesViewHolder(View itemView) {
        super(itemView);
        initView(itemView);
    }

    public void initView(View root){
        mImage = (ImageView) root.findViewById(R.id.image_item_images_list);
        mImageName = (TextView) root.findViewById(R.id.label_item_list_images_name);
        root.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mOnClickListener != null){
                    mOnClickListener.onClick(getAdapterPosition());
                }
            }
        });
    }

    public void setOnClickListener(OnClickListener onClickListener) {
        mOnClickListener = onClickListener;
    }

    public interface OnClickListener{
        void onClick(int position);
    }
}

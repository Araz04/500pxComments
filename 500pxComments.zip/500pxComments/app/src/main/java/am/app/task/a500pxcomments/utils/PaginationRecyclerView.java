package am.app.task.a500pxcomments.utils;

import android.content.Context;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.AttributeSet;

import static android.nfc.tech.MifareUltralight.PAGE_SIZE;

public class PaginationRecyclerView extends RecyclerView {

    private boolean isLoading;
    private boolean isLastPage;
    private OnPaginateListener mOnPaginateListener;

    public PaginationRecyclerView(Context context) {
        this(context, null);
    }

    public PaginationRecyclerView(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public PaginationRecyclerView(Context context, @Nullable AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        setOnScrollListener(mRecyclerViewOnScrollListener);
    }

    public boolean isLoading() {
        return isLoading;
    }

    public void setLoading(boolean loading) {
        isLoading = loading;
    }

    public boolean isLastPage() {
        return isLastPage;
    }

    public void setLastPage(boolean lastPage) {
        isLastPage = lastPage;
    }

    public void setOnPaginateListener(OnPaginateListener onPaginateListener) {
        mOnPaginateListener = onPaginateListener;
    }

    private RecyclerView.OnScrollListener mRecyclerViewOnScrollListener = new RecyclerView.OnScrollListener() {
        @Override
        public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
            super.onScrollStateChanged(recyclerView, newState);
        }

        @Override
        public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
            super.onScrolled(recyclerView, dx, dy);
            LayoutManager layoutManager = getLayoutManager();
            int visibleItemCount = layoutManager.getChildCount();
            int totalItemCount = layoutManager.getItemCount();
            int firstVisibleItemPosition;
            if (layoutManager instanceof LinearLayoutManager) {
                firstVisibleItemPosition = ((LinearLayoutManager) layoutManager).findFirstVisibleItemPosition();
            } else {
                throw new IllegalArgumentException("Unsupported LayoutManager type");
            }

            if (!isLoading && !isLastPage) {
                if ((visibleItemCount + firstVisibleItemPosition) >= totalItemCount
                        && firstVisibleItemPosition >= 0
                        && totalItemCount >= PAGE_SIZE) {
                    if (mOnPaginateListener != null) {
                        mOnPaginateListener.onLoadMore();
                    }
                }
            }
        }
    };

    public interface OnPaginateListener {
        void onLoadMore();
    }
}

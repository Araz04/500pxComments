package am.app.task.a500pxcomments.client;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

/**
 * Created by 1 on 01.04.2017.
 */

public interface ApiClient {

    String BASE_URL = "https://api.500px.com/v1/";
    String PHOTO = "photos";

    String CONSUMER_KEY = "fw9GXiRk5RTBlLoUW6PGFKi2F4qhofVvb2IarJPO";
    String POPULAR_PHOTOS = "popular";
    int PAGE = 1;
    int IMAGE_SIZE = 20;

    @GET(PHOTO)
    Call<Results.PhotoWrapper> getPhotos(@Query("consumer_key") String consumerKey,
                                         @Query("feature") String feature,
                                         @Query("page") int page,
                                         @Query("image_size") int size);
}

package am.app.task.a500pxcomments.activities;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

import com.bumptech.glide.Glide;

import am.app.task.a500pxcomments.R;
import am.app.task.a500pxcomments.adapters.CommentsAdapter;
import am.app.task.a500pxcomments.managers.ImageManager;
import am.app.task.a500pxcomments.model.Comment;
import am.app.task.a500pxcomments.model.Image;
import am.app.task.a500pxcomments.utils.Utils;

/**
 * Created by 1 on 01.04.2017.
 */

public class ImageDetailsActivity extends BaseActivity{

    public static final String PHOTO_ID = "photo.id";

    ImageView mImageCover;
    CommentsAdapter mCommentsAdapter;
    EditText mInputComment;
    Image mImage;
    ImageManager mImageManager;
    int mCommentsCount;

    private View.OnClickListener mOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId()){
                case R.id.action_activity_image_details_add_comement:
                    addComment();
                    break;
            }
        }
    };

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_details);

        mImageCover = (ImageView) findViewById(R.id.image_activity_details_cover);

        mImageManager = ImageManager.getInstance();
        init();
        fillData();
    }

    public void init(){
        mCommentsAdapter = new CommentsAdapter(this);

        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.recycler_view_comments);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(mCommentsAdapter);
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(recyclerView.getContext(),
                layoutManager.getOrientation());
        recyclerView.addItemDecoration(dividerItemDecoration);

        mInputComment = (EditText) findViewById(R.id.input_activity_image_details_comment);
        findViewById(R.id.action_activity_image_details_add_comement).setOnClickListener(mOnClickListener);
    }

    private void fillData() {
        int photoId = getIntent().getIntExtra(PHOTO_ID, -1);
        if (photoId == -1) {
            throw new IllegalStateException("Photo id argument not provided");
        }

        mImage = mImageManager.getImageById(photoId);

        Glide.with(this).load(mImage.getImageUrl()).into(mImageCover);
        Glide.with(this).load(mImage.getImageUrl()).centerCrop().into(mImageCover);
        mCommentsAdapter.addComments(mImage.getComments());
        mCommentsCount = mCommentsAdapter.getItemCount();
    }

    private void addComment() {
        String commentText = mInputComment.getText().toString();
        Comment comment = new Comment(commentText);
        if (!TextUtils.isEmpty(commentText)) {
            mCommentsAdapter.addComment(comment);
            mImage.getComments().add(comment);
            mInputComment.setText("");
            mInputComment.clearFocus();
            Utils.hideKeyboard(this);
        }
    }
}

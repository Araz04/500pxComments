package am.app.task.a500pxcomments.model;

/**
 * Created by 1 on 01.04.2017.
 */

public class Comment {
    String mComment;

    public Comment(String comment) {
        mComment = comment;
    }

    public String getComment() {
        return mComment;
    }
}
